package com.example.srikanth.limitservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.srikanth.limitservice.bean.LimitConfig;

@RestController
public class LimitsConfigurationController {
	@Autowired
	Configuration configuration;
	@GetMapping("/limits")
	public LimitConfig retriveLimitsFromConfig() {
		
		return new LimitConfig(configuration.getMaximum(),configuration.getMinimum());
	}

}
