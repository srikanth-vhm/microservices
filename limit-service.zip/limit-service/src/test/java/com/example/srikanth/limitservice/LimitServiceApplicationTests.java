package com.example.srikanth.limitservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimitServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
